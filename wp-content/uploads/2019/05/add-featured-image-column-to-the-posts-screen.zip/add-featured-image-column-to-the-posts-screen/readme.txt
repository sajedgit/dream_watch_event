=== Wp-ImageColumn ===
Contributors: Md. Sajed Ahmed Khan
Donate link: 
Tags: post,posts, admin, images,feature image
Requires at least: 3.0
Tested up to: 4.1
Stable tag: 3.2.1
License: GPLv2 or later
License URI: 

Add featured image Column to the WP Posts Screen

== Description ==
This plugin is used for add a custom column field to post screen like post title,post category etc.This plugin is create a new column 
named "Featured Image" and the content is the particular post's feature image which is uploaded by the wp-admin Post page.When this
plugin activated you will see the Featured Image box at bottom right side of Add New Post page and also you'll see the new "Featured Image" 
column on the manage Posts screen.

== Installation ==

1. Upload the  plugin from the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Then  go to the Add New/Edit Post page and set the feature image by Featured Image box at bottom right side of Post page.
4. After set the feature image go to the manage Posts page of wp-admin.
5. And you can see a new column named "Featured Image" and the feature image of the particular post.

 
 == Frequently Asked Questions ==

= Are there need to add any short code ? =

No. There are no need to add any short code.


== Screenshots ==


1. Manage Posts page.
2. Featured Image box on Add New/Edit Post page

== Changelog ==

= 1.0 =

* List versions from most recent at top to oldest at bottom.


== Upgrade Notice ==

=1.0 =
This version fixes a security related bug.  Upgrade immediately.


 
